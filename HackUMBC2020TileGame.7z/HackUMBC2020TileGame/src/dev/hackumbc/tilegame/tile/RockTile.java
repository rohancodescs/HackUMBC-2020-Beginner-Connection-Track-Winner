package dev.hackumbc.tilegame.tile;

import dev.hackumbc.tilegame.gfx.Assets;

public class RockTile extends Tile {

	public RockTile(int id) {
		super(Assets.rocktile, id);
	}
	
	@Override
	public boolean isSolid() {
		return true;
	}
	
}

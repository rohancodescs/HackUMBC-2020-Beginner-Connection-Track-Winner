package dev.hackumbc.tilegame.tile;

import dev.hackumbc.tilegame.gfx.Assets;

public class DarknessTile extends Tile {

	public DarknessTile(int id) {
		super(Assets.darkness, id);
	}
	
	@Override
	public boolean isSolid() {
		return true;
	}
	
}
